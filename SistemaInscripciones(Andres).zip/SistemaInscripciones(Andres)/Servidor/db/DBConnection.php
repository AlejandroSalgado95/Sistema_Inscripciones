<?php
class DBConnection{

    public static function conexion(){

    	$servername = "localhost";
		$username = "root";
		$password = "root";
		$dbname = "sistemainscripciones";
		$port = "3307";

		$conn = new mysqli($servername, $username, $password, $dbname,$port);
		mysqli_set_charset($conn,"utf8");

        return $conn;
    }

     
}
?>